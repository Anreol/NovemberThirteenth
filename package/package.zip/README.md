# GummyMan

Plays "The Life of the Party is 26 POUNDS" or "The Gummy Bear Song" on bodies that are identified as gummy clones. That's all. That's the mod.
Feel free to use the code as a example on how to implement Wwise in your mod.

### Contact
You can contact me by messaging to Anreol on the Discord Messaging Platform

## Changelog
**0.0.3**
* Recompiled for ver. 1.3.1#274

**0.0.2**
* Null checked the body and inventory objects because it'd throw issues with bodies that had no inventories.
* FixedUpdate is now a Update cycle.
* Hopefully I will never have to update it again.


**0.0.1**
* Initial Release
* 0.0.1 because i'm lazy and i forgot to change the version number in vs